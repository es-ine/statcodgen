# -*- coding: utf-8 -*-
"""
Created on Tue Jul  9 14:04:30 2024

@author: git.metodologia@ine.es
"""

import pathlib
from setuptools import find_packages, setup

HERE = pathlib.Path(__file__).parent
VERSION = '1.0.0'  # you should update the version of your library as you add new functionalities
PACKAGE_NAME = 'codauto'  # It must match the name of the folder where the code is located
AUTHOR = 'Unidad de clasificaciones INE'
AUTHOR_EMAIL = 'git.metodologia@ine.es'
URL = 'https://gitlab.ine.es/prod-estadistica/metodologia/clasificaciones/cod-auto'
LICENSE = 'EUPL European Public License'  # License type
DESCRIPTION = "Library for training an autoencoder"  # Short description
LONG_DESCRIPTION = (HERE / "README.md").read_text(encoding='utf-8')  # Reference to the README file with a more detailed description
LONG_DESC_TYPE = "text/markdown"
INSTALL_REQUIRES = [
    'pandas',
    'numpy',
    'pyreadstat',
    'utils',
    'fasttext-wheel',
    'openpyxl',
    'matplotlib',
    'scikit-learn',
    'nltk',
    'xlrd',
    'torch',
    'transformers'
]  # Required packages for the library. They will be installed automatically if not already present

setup(
    name=PACKAGE_NAME,
    version=VERSION,
    description=DESCRIPTION,
    long_description=LONG_DESCRIPTION,
    long_description_content_type=LONG_DESC_TYPE,
    author=AUTHOR,
    author_email=AUTHOR_EMAIL,
    url=URL,
    install_requires=INSTALL_REQUIRES,
    license=LICENSE,
    packages=find_packages(),
    include_package_data=True
)
